# FloorForge AI — Aggressive B2B Social Ad Campaign Assets

**Campaign Objective:** Drive immediate trial sign-ups and demo bookings from flooring contractors and master artisans to https://floorforge-ai.vercel.app

**Tone:** Pattern-interrupting, pain-point aggressive, zero corporate fluff. Direct-response B2B SaaS.

**Platforms:** LinkedIn (primary), Facebook/Instagram ads, organic social.

---

## Asset Inventory

| # | Image | Focus | Filename |
|---|-------|-------|----------|
| 1 | The Blueprint Scanner | Instant AI Estimation | `01_blueprint_scanner.webp` |
| 2 | The Waste Killer | Material Savings & Efficiency | `02_waste_killer.webp` |
| 3 | The Kitchen Table Close-Out | Speed to Close & Professionalism | `03_kitchen_table_closeout.webp` |
| 4 | The Multi-Site Command Center | Business Scaling & Operations | `04_multisite_command_center.webp` |
| 5 | The Margin Multiplier | Profitability & Growth | `05_margin_multiplier.webp` |

All images are photorealistic, 8k-style DSLR aesthetic, saved as high-quality WebP + JPG originals.

---

## Ad Package 1 — The Blueprint Scanner

**Hook (first 3 lines):**
Stop spending your weekends measuring blueprints and guessing your material waste.
If you're still tracing plans by hand, you're already losing the bid.
Your competitors just scanned the entire floor plan in 12 seconds.

**Body:**
FloorForge AI turns any architectural PDF into a precision takeoff in under 60 seconds. Instant room detection. Live square footage. Real-time waste percentage. No more weekends with a scale ruler and a calculator. Upload the blueprint, get the fixed-price quote, and walk into the meeting knowing your numbers are locked. Manual measuring errors? Eliminated. Guesswork on waste factors? Dead. This is the end of the estimating bottleneck that keeps your crews waiting and your margins bleeding.

**Caption / Description:**
Blueprint to bid in 60 seconds. FloorForge AI scans the plan, calculates the cut list, and locks your price before the GC hangs up. Stop losing jobs to slower estimators. #FloorForgeAI #FlooringContractor #ConstructionTech #HardwoodFlooring #BusinessAutomation #AIEstimation #TakeoffSoftware

**CTA:**
Start your free trial or request a live demo → floorforge-ai.vercel.app

---

## Ad Package 2 — The Waste Killer

**Hook (first 3 lines):**
That pile of scrap wood isn't leftover — it's your lost profit.
Every job where you over-order or miscut is money walking out the door.
98.4% material yield isn't a dream. It's FloorForge default.

**Body:**
FloorForge's cut-list optimizer doesn't just measure. It nests every plank, tile, or board for maximum yield across the entire job. Automated waste reduction that turns 12-15% scrap into under 2%. Your suppliers will notice the smaller orders. Your bank account will notice the bigger margins. No more ordering 10% extra "just in case." No more Friday afternoon dumps of wasted material. The dashboard shows you the exact cut sequence, the exact yield, and the exact dollars you just saved. Scale your material efficiency without hiring another estimator.

**Caption / Description:**
98.4% yield. Zero guesswork. FloorForge AI kills waste before the first board hits the saw. Your scrap pile just became profit. #FloorForgeAI #FlooringContractor #ConstructionTech #MaterialOptimization #HardwoodFlooring #WasteReduction #BusinessAutomation

**CTA:**
See the yield numbers on your next job — start free trial at floorforge-ai.vercel.app

---

## Ad Package 3 — The Kitchen Table Close-Out

**Hook (first 3 lines):**
The homeowner is ready to sign. Are you still calculating on a napkin?
If you can't hand them a fixed-price quote in under 60 seconds, the job is already walking to the next guy.
Professionalism wins the close. Speed seals it.

**Body:**
FloorForge mobile generates a polished, branded, fixed-price PDF quote on-site before the coffee gets cold. Scan the plan or walk the rooms, lock the numbers, print or email the professional proposal, and close while the emotion is high. No more "I'll get back to you with a number." No more lost deals because your estimate took three days. Contractors using FloorForge walk out with signed contracts the same day. The quote looks like it came from a Fortune 500 operation — because the software behind it is. Stop competing on price alone. Compete on speed and polish.

**Caption / Description:**
Quote generated. Contract signed. Coffee still warm. FloorForge turns the kitchen table into your closing office in under 60 seconds. #FloorForgeAI #FlooringContractor #ConstructionTech #SpeedToClose #HardwoodFlooring #ProfessionalQuotes #BusinessAutomation

**CTA:**
Book a demo and close your next job the same day → floorforge-ai.vercel.app

---

## Ad Package 4 — The Multi-Site Command Center

**Hook (first 3 lines):**
You can't scale a flooring company if you're the bottleneck on every job.
Five crews. Five cities. Zero visibility. That's not growth — that's chaos.
One dashboard. Live crews. Live moisture. Live deliveries. That's FloorForge.

**Body:**
FloorForge is the command center that lets you run multiple jobs without drowning in admin. Track active installation crews in real time. Pull moisture test results before the truck leaves the yard. Coordinate material deliveries across five different sites without a single phone call. The multi-project dashboard turns your operation from reactive firefighting into proactive scaling. No more spreadsheets. No more "where's the crew" texts. No more missed deliveries that kill the schedule. Grow the business without growing the overhead. This is how master contractors become multi-crew operations without losing control.

**Caption / Description:**
One screen. Five cities. Zero chaos. FloorForge multi-site command center keeps every crew, every delivery, and every moisture reading under control. Scale without the admin tax. #FloorForgeAI #FlooringContractor #ConstructionTech #BusinessScaling #OpsAutomation #HardwoodFlooring #MultiCrew

**CTA:**
See the multi-site dashboard in a custom demo → floorforge-ai.vercel.app

---

## Ad Package 5 — The Margin Multiplier

**Hook (first 3 lines):**
Your margins aren't thin because of the market. They're thin because of the process.
35% margin increase isn't marketing fluff. It's what happens when waste, errors, and admin vanish.
Keys. Laser. Coffee. Profit screen. That's the new jobsite toolkit.

**Body:**
FloorForge doesn't just estimate faster. It multiplies your net. Automated takeoffs eliminate underbidding. Cut-list optimization kills material waste. On-site quoting closes more jobs at higher prices. Live ops visibility stops the bleeding on job costs. The P&L analytics show you exactly where the 35% comes from — every job, every month. Stop leaving money on the floor. Stop letting inefficient processes eat the profit that should be yours. This is the software that turns a solid flooring contractor into a high-margin, scalable operation. The tools on the table are the same. The software behind them is what changes the game.

**Caption / Description:**
35% margin lift. Same tools. Different software. FloorForge turns estimation, waste, and ops into pure profit. The new standard for flooring contractors who refuse to stay average. #FloorForgeAI #FlooringContractor #ConstructionTech #ProfitMargins #BusinessGrowth #HardwoodFlooring #SaaS

**CTA:**
Start the free trial and watch your next P&L change → floorforge-ai.vercel.app

---

## Deployment Instructions

1. Extract `floorforge_social_campaign.zip`
2. Place all `.webp` (and optional `.jpg`) files + `floorforge_campaign_assets.json` into the monorepo path:
   `public/assets/marketing/`
3. Keep existing marketing assets untouched.

### Exact Git CLI Commands

```bash
# From the root of the iceccarelli/floorforge-ai monorepo
mkdir -p public/assets/marketing

# After extracting the zip contents into a temp folder (e.g. /tmp/floorforge_campaign)
cp /tmp/floorforge_campaign/*.webp public/assets/marketing/
cp /tmp/floorforge_campaign/floorforge_campaign_assets.json public/assets/marketing/
cp /tmp/floorforge_campaign/README_FloorForge_Campaign.md public/assets/marketing/

git add public/assets/marketing/
git commit -m "feat(marketing): add FloorForge aggressive B2B social campaign assets (5 images + structured copy JSON)"
git push origin main
```

---

**Generated:** 2026-07-26  
**Brand Alignment Note:** Campaign copy follows the requested value props (AI blueprint scanning, 60-sec quoting, cut-list optimization, margin scaling). Actual live product at floorforge-ai.vercel.app currently focuses on autonomous refinishing systems; update landing page CTAs/copy as product evolves to match campaign claims.
