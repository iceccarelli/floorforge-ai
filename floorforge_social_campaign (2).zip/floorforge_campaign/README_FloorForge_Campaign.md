# FloorForge AI — Aggressive B2B Social Ad Campaign Package

**Objective:** Drive immediate trial signups and demo bookings for FloorForge AI from flooring contractors and multi-crew operations via LinkedIn, Facebook, and Instagram paid ads.

**Core Value Props Weaponized:**
- Instant AI floor plan blueprint scanning
- 60-second fixed-price quoting
- Automated waste reduction & cut-list optimization (target 98%+ yield)
- Scaling contractor profit margins without admin bloat

---

## Campaign Assets

### 01 — The Blueprint Scanner
**Focus:** Instant AI Estimation  
**Image:** `images/01_blueprint_scanner.webp`

**Hook (first 3 lines):**
Stop spending your weekends measuring blueprints and guessing your material waste.  
If you're still tracing floor plans by hand, you're already losing money.  
Your competitors just closed three jobs while you were still counting square feet.

**Body:**
FloorForge AI scans any architectural floor plan the second you upload it. Instant room detection. Real-time square footage. Automated waste percentage. Fixed-price quotes generated in under 60 seconds — right on the job site or in the office.

No more spreadsheets. No more manual errors that kill your margin. No more saying "I'll get back to you" while you stay up late calculating.

Upload the blueprint. Get the cut-list. Lock the price. Walk out with the deposit.

This is how modern flooring contractors scale without adding admin headcount.

**Caption:**
Instant AI floor plan scanning that turns blueprints into fixed-price quotes in 60 seconds. Stop guessing. Start winning. #FloorForgeAI #FlooringContractor #ConstructionTech #HardwoodFlooring #BusinessAutomation #AIEstimating #CutListOptimization

**CTA:**
Start your free trial or book a live demo → floorforge-ai.vercel.app

---

### 02 — The Waste Killer
**Focus:** Material Savings & Efficiency  
**Image:** `images/02_waste_killer.webp`

**Hook:**
That pile of scrap wood isn't "just how flooring is."  
It's pure lost profit sitting on your shop floor.  
Every 8–12% waste factor you pad into a bid is money you leave on the table — or worse, money that makes you lose the job.

**Body:**
FloorForge AI doesn't guess cut lists. It optimizes them.

Upload the plan. Select the plank width and pattern. Watch the engine deliver 98%+ material yield while generating the exact cut sequence your installers need.

No more over-ordering "just in case." No more last-minute supplier runs. No more watching good oak end up in the dumpster.

Contractors using FloorForge report material cost drops that go straight to the bottom line — while still delivering tighter, cleaner installs.

Your waste pile is your competitor's profit. Kill it.

**Caption:**
98.4% material yield. Automated cut-list optimization that turns scrap into margin. The waste killer for serious flooring operations. #FloorForgeAI #FlooringContractor #ConstructionTech #HardwoodFlooring #WasteReduction #CutList #BusinessAutomation

**CTA:**
See the yield engine yourself — start free trial or request demo at floorforge-ai.vercel.app

---

### 03 — The Kitchen Table Close-Out
**Focus:** Speed to Close & Professionalism  
**Image:** `images/03_kitchen_table_closeout.webp`

**Hook:**
The homeowner is ready to buy right now.  
You're still saying "I'll email you a quote tomorrow."  
By tomorrow, two other contractors have already left fixed-price PDFs on their table.

**Body:**
FloorForge lets you walk into any home, scan the space or upload the plans, and hand the client a polished, branded fixed-price quote before you leave the kitchen table.

Under 60 seconds. Professional PDF. Accurate material + labor. Zero second-guessing later.

This is the difference between "we'll think about it" and "here's the deposit."

Speed closes deals. Professionalism builds trust. FloorForge gives you both — on site, every single time.

Stop losing jobs to the guy who shows up with software that works.

**Caption:**
60-second fixed-price quotes. On-site. Branded. Professional. Close more jobs at the kitchen table. #FloorForgeAI #FlooringContractor #ConstructionTech #HardwoodFlooring #SalesSpeed #BusinessAutomation

**CTA:**
Generate your first quote free — start trial or book demo → floorforge-ai.vercel.app

---

### 04 — The Multi-Site Command Center
**Focus:** Business Scaling & Operations  
**Image:** `images/04_multi_site_command.webp`

**Hook:**
Running five crews across three cities shouldn't require five different spreadsheets and constant phone calls.  
If your "system" is still group texts and paper moisture logs, you're the bottleneck — not the boss.

**Body:**
FloorForge is the command center for modern flooring operations.

Live multi-project dashboard. Real-time crew status. Moisture test results logged and tracked. Material deliveries coordinated. Progress visible from your office or phone.

Scale from one truck to a regional operation without drowning in admin or hiring a full-time project manager just to keep the lights on.

See every job. Spot delays before they cost you. Keep quality consistent across every crew.

This is how flooring businesses stop being jobs and start being companies.

**Caption:**
Multi-site command center for flooring contractors. Track crews, moisture, deliveries, and profit across every job from one dashboard. #FloorForgeAI #FlooringContractor #ConstructionTech #BusinessScaling #OperationsSoftware #HardwoodFlooring

**CTA:**
See the multi-project dashboard — start free trial or schedule demo at floorforge-ai.vercel.app

---

### 05 — The Margin Multiplier
**Focus:** Profitability & Growth  
**Image:** `images/05_margin_multiplier.webp`

**Hook:**
Most flooring contractors work harder every year and take home the same — or less.  
The ones printing money aren't working harder. They're measuring everything and killing the leaks.

**Body:**
FloorForge turns every job into clean P&L data.

See exactly where your margin is made or lost. Track true material yield, labor hours, change orders, and overhead allocation in real time.

Users report 30%+ margin lifts once the guesswork is gone and the numbers are visible.

This isn't another dashboard you ignore. It's the difference between hoping you're profitable and knowing you are — then scaling the jobs that actually print money.

Stop flying blind. Start multiplying margin.

**Caption:**
35% margin increase. Real-time P&L that shows exactly where your flooring business makes (or loses) money. The margin multiplier. #FloorForgeAI #FlooringContractor #ConstructionTech #ProfitMargins #BusinessAutomation #HardwoodFlooring

**CTA:**
Unlock your real margins — start free trial or book a custom demo → floorforge-ai.vercel.app

---

## Deployment Instructions

1. Unzip `floorforge_social_campaign.zip`
2. Copy the entire contents into the monorepo at `public/assets/marketing/floorforge_social_campaign/` (or equivalent path)
3. Do **not** overwrite any existing marketing assets
4. Commit with the provided Git commands

## Notes for Media Buyers
- Primary platforms: LinkedIn (highest B2B intent), Meta (Facebook + Instagram)
- Recommended creative testing: Start with Image 01 + 03 for awareness, 02 + 05 for conversion
- Audience: Job titles containing "Flooring", "Estimator", "Owner", "Project Manager" + interests in hardwood, construction software, etc.
- Landing page: floorforge-ai.vercel.app (or production domain once live)

