# FloorForge AI — Aggressive B2B Social Ad Campaign Package

**Objective:** Drive immediate trial signups and demo bookings for FloorForge AI from flooring contractors and multi-crew operations via LinkedIn, Facebook, and Instagram paid ads.

**Core Value Props Weaponized:**
- Instant AI floor plan blueprint scanning
- 60-second fixed-price quoting
- Automated waste reduction & cut-list optimization (target 98%+ yield)
- Scaling contractor profit margins without admin bloat

**Brand Voice:** Aggressive, pattern-interrupting, no-corporate-fluff, contractor-to-contractor, profit-first. Hit the pain hard. No soft language.

**Primary CTA Destination:** [floorforge-ai.vercel.app](https://floorforge-ai.vercel.app)

---

## Campaign Assets

### 01 — The Blueprint Scanner
**Focus:** Instant AI Estimation  
**Image:** `images/01_blueprint_scanner.webp`

**Hook (first 3 lines):**
Stop spending your weekends measuring blueprints and guessing your material waste.  
If you're still tracing floor plans by hand, you're already losing money.  
Your competitors just closed three jobs while you were still counting square feet.

**Body:**
FloorForge AI scans any architectural floor plan the second you upload it. Instant room detection. Real-time square footage. Automated waste percentage counters right on the screen.

Fixed-price quotes generated in under 60 seconds — on the job site or in the truck.

No more spreadsheets. No more manual measuring errors that destroy your margin. No more telling clients "I'll get back to you."

This is the end of the estimation bottleneck. Upload. Scan. Quote. Close.

**Caption / Description:**
Instant AI blueprint scanning that turns floor plans into accurate takeoffs in seconds. Stop measuring. Start winning jobs. #FloorForgeAI #FlooringContractor #ConstructionTech #HardwoodFlooring #BusinessAutomation #AIEstimating #FlooringTakeoff

**CTA:**
Start your free trial or book a custom demo → floorforge-ai.vercel.app

---

### 02 — The Waste Killer
**Focus:** Material Savings & Efficiency  
**Image:** `images/02_waste_killer.webp`

**Hook (first 3 lines):**
That pile of scrap wood isn't "just how flooring is."  
It's pure lost profit sitting on your shop floor.  
Every 8–12% waste factor you pad into a bid is money you leave on the table — or the reason you lose the job.

**Body:**
FloorForge AI doesn't guess cut lists. It optimizes them.

Upload the plan. Select plank width, pattern, and grain direction. Watch the engine deliver 98%+ material yield while generating the exact cut sequence your installers need on site.

No more over-ordering "just in case." No more emergency supplier runs. No more watching premium white oak end up in the dumpster.

Contractors who kill waste with FloorForge put those dollars straight into margin — while still delivering tighter, cleaner installs that win referrals.

Your waste pile is your competitor's profit. End it.

**Caption / Description:**
98.4% material yield. Automated cut-list optimization that turns scrap into pure margin. The waste killer for serious flooring operations. #FloorForgeAI #FlooringContractor #ConstructionTech #HardwoodFlooring #WasteReduction #CutListOptimization #BusinessAutomation

**CTA:**
See the yield engine yourself — start free trial or request demo at floorforge-ai.vercel.app

---

### 03 — The Kitchen Table Close-Out
**Focus:** Speed to Close & Professionalism  
**Image:** `images/03_kitchen_table_closeout.webp`

**Hook (first 3 lines):**
The homeowner is ready to buy right now.  
You're still saying "I'll email you a quote tomorrow."  
By tomorrow, two other contractors have already left fixed-price PDFs on their table.

**Body:**
FloorForge lets you walk into any home, scan the space or upload the plans, and hand the client a polished, branded fixed-price quote before you leave the kitchen table.

Under 60 seconds. Professional PDF. Accurate material + labor. Zero second-guessing later.

This is the difference between "we'll think about it" and "here's the deposit."

Speed closes deals. Professionalism builds trust. FloorForge gives you both — on site, every single time.

Stop losing jobs to the guy who shows up with software that actually works.

**Caption / Description:**
60-second fixed-price quotes generated on-site. Walk in measuring. Walk out with the deposit. Professionalism that closes. #FloorForgeAI #FlooringContractor #ConstructionTech #HardwoodFlooring #SalesClose #BusinessAutomation #FlooringBusiness

**CTA:**
Get the close-out advantage — start free trial or book demo at floorforge-ai.vercel.app

---

### 04 — The Multi-Site Command Center
**Focus:** Business Scaling & Operations  
**Image:** `images/04_multisite_command_center.webp`

**Hook (first 3 lines):**
You're still running five jobs out of a notebook and three group chats.  
One missed moisture reading. One delayed delivery. One crew standing around.  
That's how scaling turns into chaos — and chaos kills margin.

**Body:**
FloorForge is the multi-site command center for flooring contractors who refuse to stay small.

Live dashboard tracking active installation crews, real-time moisture test results, material deliveries, and progress across every job in every city.

See the whole operation at a glance. Spot problems before they cost you. Scale crews without adding admin staff.

This is how you go from "busy but broke" to running a true flooring enterprise — without drowning in spreadsheets and phone calls.

The contractors who control their operations own the market. FloorForge puts that control in your hands.

**Caption / Description:**
Multi-project command center for flooring contractors who scale. Track crews, moisture, deliveries across every site — live. #FloorForgeAI #FlooringContractor #ConstructionTech #HardwoodFlooring #BusinessAutomation #OperationsManagement #ScaleYourBusiness

**CTA:**
Take command of your operations — start free trial or book demo at floorforge-ai.vercel.app

---

### 05 — The Margin Multiplier
**Focus:** Profitability & Growth  
**Image:** `images/05_margin_multiplier.webp`

**Hook (first 3 lines):**
You're working harder than ever.  
Your crew is solid. Your installs look great.  
But your margins are still stuck in the teens while the market moves past you.

**Body:**
FloorForge is the margin multiplier.

AI estimation eliminates the 5–8% errors that silently bleed every job. Cut-list optimization recovers the 8–12% material waste you used to pad. On-site quoting wins more work at higher prices because you look professional and decisive.

The result? Contractors using the full suite report margin increases of 30%+ while taking on more volume with the same overhead.

This isn't "software that helps." This is the operating system that turns a good flooring business into a high-margin machine.

Stop leaving money on every job. Start compounding it.

**Caption / Description:**
35% margin increase. The FloorForge suite that turns estimation, waste, and operations into pure profit. Built for contractors who refuse to stay average. #FloorForgeAI #FlooringContractor #ConstructionTech #HardwoodFlooring #ProfitMargins #BusinessAutomation #ContractorGrowth

**CTA:**
Multiply your margins — start free trial or request demo at floorforge-ai.vercel.app

---

## Packaging Notes

- All images are high-resolution WebP optimized for web/ad platforms.
- JSON (`floorforge_campaign_assets.json`) is structured for programmatic consumption (ad managers, dynamic creative tools, CMS).
- This Markdown is human-readable source of truth.

## Git Deployment Commands

Assuming you have the monorepo cloned and are on the correct branch:

```bash
# 1. Extract the campaign package into the marketing assets directory
unzip -o floorforge_social_campaign.zip -d public/assets/marketing/

# 2. Verify structure
ls -la public/assets/marketing/
# Expected: images/ folder + floorforge_campaign_assets.json + README_FloorForge_Campaign.md

# 3. Stage without overwriting unrelated prior marketing materials
git add public/assets/marketing/images/01_blueprint_scanner.webp \
        public/assets/marketing/images/02_waste_killer.webp \
        public/assets/marketing/images/03_kitchen_table_closeout.webp \
        public/assets/marketing/images/04_multisite_command_center.webp \
        public/assets/marketing/images/05_margin_multiplier.webp \
        public/assets/marketing/floorforge_campaign_assets.json \
        public/assets/marketing/README_FloorForge_Campaign.md

# 4. Commit
git commit -m "feat(marketing): add FloorForge AI aggressive B2B social ad campaign assets (5 images + copy packages)"

# 5. Push
git push origin HEAD
```

**Note:** The `-o` flag on unzip overwrites only matching filenames. Existing non-conflicting files in `public/assets/marketing/` remain untouched.
